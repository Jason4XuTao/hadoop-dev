package org.conan.mymahout.recommendation.job;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.mahout.cf.taste.common.TasteException;
import org.apache.mahout.cf.taste.eval.RecommenderBuilder;
import org.apache.mahout.cf.taste.impl.common.LongPrimitiveIterator;
import org.apache.mahout.cf.taste.model.DataModel;
import org.apache.mahout.cf.taste.recommender.IDRescorer;
import org.apache.mahout.cf.taste.recommender.RecommendedItem;

public class RecommenderFilterSalaryResult {

    final static int NEIGHBORHOOD_NUM = 2;
    final static int RECOMMENDER_NUM = 3;

    public static void main(String[] args) throws TasteException, IOException {
        String file = "datafile/job/pv.csv";
        DataModel dataModel = RecommendFactory.buildDataModelNoPref(file);
        RecommenderBuilder rb1 = RecommenderEvaluator.userCityBlock(dataModel);
        RecommenderBuilder rb2 = RecommenderEvaluator.itemLoglikelihood(dataModel);

//        LongPrimitiveIterator iter = dataModel.getUserIDs();
//        while (iter.hasNext()) {
//            long uid = iter.nextLong();
//            System.out.print("userCityBlock    =>");
//            filterLowPay(uid, rb1, dataModel);
//            System.out.print("itemLoglikelihood=>");
//            filterLowPay(uid, rb2, dataModel);
//        }
        
        long uid = 974;
        System.out.print("filter by salary : userCityBlock    =>");
        filterLowPay(uid, rb1, dataModel);
        System.out.print("filter by salary : itemLoglikelihood=>");
        filterLowPay(uid, rb2, dataModel);

        System.out.print("filter by outdate : userCityBlock    =>");
        RecommenderFilterOutdateResult.filterOutdate(uid, rb1, dataModel);
        System.out.print("filter by outdate : itemLoglikelihood=>");
        RecommenderFilterOutdateResult.filterOutdate(uid, rb2, dataModel);
        
    }

    public static void filterLowPay(long uid, RecommenderBuilder recommenderBuilder, DataModel dataModel) throws TasteException, IOException {
    	Set<Long> jobids = getLowPayJobids("datafile/job/job.csv", "datafile/job/pv.csv", uid);
        IDRescorer rescorer = new JobRescorer(jobids);
        List<RecommendedItem> list = recommenderBuilder.buildRecommender(dataModel).recommend(uid, RECOMMENDER_NUM, rescorer);
        RecommendFactory.showItems(uid, list, false);
    }

    public static Set<Long> getLowPayJobids(String jobfile, String pvfile, long uid) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(new File(jobfile)));
        String s = null;
        Map<String, Double> jobPayMap = new HashMap<String, Double>();
        while ((s = br.readLine()) != null) {
            String[] cols = s.split(",");
            String job = cols[0];
            Double pay = Double.parseDouble(cols[2]);
            jobPayMap.put(job, pay);
        }
        br.close();
        
    	br = new BufferedReader(new FileReader(new File(pvfile)));
        s = null;
        Map<String, HashMap<String, Double>> userPayMap = new HashMap<String, HashMap<String, Double>>();
        while ((s = br.readLine()) != null) {
            String[] cols = s.split(",");
            String user = cols[0];
            String job = cols[1];
            if(userPayMap.containsKey(user)){
            	userPayMap.get(user).put(job, jobPayMap.get(job));
            } else {
                HashMap<String, Double> curJobPayMap = new HashMap<String, Double>();
                curJobPayMap.put(job, jobPayMap.get(job));
            	userPayMap.put(user, curJobPayMap);
            }
        }
        br.close();

    	double totPay = 0;
    	int i = 0;
    	for(Map.Entry<String, Double> jobPay : userPayMap.get(String.valueOf(uid)).entrySet()) {
    		totPay += jobPay.getValue();
    		i++;
    	}
    	double avgPay = totPay / i * 0.8;

        Set<Long> jobids = new HashSet<Long>();
        for(Map.Entry<String, Double> jobPayEntry : jobPayMap.entrySet()){
        	if(jobPayEntry.getValue().doubleValue() < avgPay)
        		jobids.add(Long.valueOf(jobPayEntry.getKey()));
        }
        return jobids;
    }

}

class JobRescorer implements IDRescorer {
    final private Set<Long> jobids;

    public JobRescorer(Set<Long> jobids) {
        this.jobids = jobids;
    }

    @Override
    public double rescore(long id, double originalScore) {
        return isFiltered(id) ? Double.NaN : originalScore;
    }

    @Override
    public boolean isFiltered(long id) {
        return jobids.contains(id);
    }
}
