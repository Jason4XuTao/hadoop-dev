package com.hadoop.matrix;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Mapper.Context;

public class Matrix_Reducer extends Reducer<Text, Text, Text, IntWritable>
{

	private int joinNum = 4;// col num for matirx a, which equals to row num for matrix b

	@Override
	protected void setup(Context context) throws IOException,
			InterruptedException {
		Configuration conf = context.getConfiguration();
		joinNum = Integer.parseInt(conf.get("joinNum"));
		System.out.println("joinNum from Mapper setup function = " + joinNum);
	}

	/**
	 * Reducer do the actual matrix multiplication.
	 * @param key is the cell unique cell dimension (00) represents cell 0,0
	 * @value values required to calculate matrix multiplication result of that cell.
	 */
	
	@Override
	protected void reduce(Text key, Iterable<Text> values,Context context)
						throws IOException, InterruptedException 
	{
		System.out.println("Inside Reduce !");
		int[] row = new int[joinNum]; 
		int[] col = new int[joinNum];
		
		for(Text val : values)
		{
			String[] entries = val.toString().split(",");
			if(entries[0].matches("a"))
			{
				int index = Integer.parseInt(entries[2].trim());
				row[index] = Integer.parseInt(entries[3].trim());
			}
			if(entries[0].matches("b"))
			{
				int index = Integer.parseInt(entries[1].trim());
				col[index] = Integer.parseInt(entries[3].trim());
			}
		}
		System.out.println("row array: " + java.util.Arrays.toString(row));
		System.out.println("column array: " + java.util.Arrays.toString(col));

		
		// Let us do matrix multiplication now..
		int total = 0;
		for(int i = 0 ; i < 5; i++)
		{
			total += row[i]*col[i];
		}
		System.out.println(key.toString() + "-" + total );
		context.write(key, new IntWritable(total));
	
	}
	
}
