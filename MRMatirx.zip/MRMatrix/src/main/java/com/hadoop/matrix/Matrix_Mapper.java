package com.hadoop.matrix;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;

public class Matrix_Mapper extends Mapper<LongWritable, Text, Text, Text> {

	private int rowNum = 4;// row num for matirx a
	private int colNum = 2;// col num for matrix b

	@Override
	protected void setup(Context context) throws IOException,
			InterruptedException {
		Configuration conf = context.getConfiguration();
		rowNum = Integer.parseInt(conf.get("rowNum"));
		colNum = Integer.parseInt(conf.get("colNum"));
		System.out.println("rowNum from Mapper setup function = " + rowNum);
		System.out.println("colNum from Mapper setup function = " + colNum);
	}

	/**
	 * Map function will collect/ group cell values required for calculating the
	 * output.
	 * 
	 * @param key	is ignored. Its just the byte offset
	 * @param value	is a single line. (a, 0, 0, 63) (matrix name, row, column, value)
	 * 
	 */

	@Override
	protected void map(LongWritable key, Text value, Context context)
			throws IOException, InterruptedException {
		System.out.println("Inside Map !");
		String line = value.toString();
		String[] entry = line.split(",");
		String sKey = "";
		String mat = entry[0].trim();

		String row, col;

		if (mat.matches("a")) {
			row = entry[1].trim(); // rowid
			for (int k = 0; k < colNum; k++)
			{
				sKey = row + "," + k;
				System.out.println(sKey + "-" + value.toString());
				context.write(new Text(sKey), value);
			}
		}

		if (mat.matches("b")) {
			col = entry[2].trim(); // colid
			for (int k = 0; k < rowNum; k++) {
				sKey = k + "," + col;
				System.out.println(sKey + "-" + value.toString());
				context.write(new Text(sKey), value);
			}
		}

	}

}
