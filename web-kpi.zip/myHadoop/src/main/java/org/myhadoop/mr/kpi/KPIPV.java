package org.myhadoop.mr.kpi;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class KPIPV {
	public static class KPIPVMapper extends
			Mapper<LongWritable, Text, Text, IntWritable> {
		private IntWritable one = new IntWritable(1);
		private Text word = new Text();

		public void map(LongWritable key, Text value, Context context)
				throws IOException, InterruptedException {
			KPI kpi = KPI.filterPVs(value.toString());
			if (kpi.isValid()) {
				word.set(kpi.getRequest());
				context.write(word, one);
			}
		}
	}

	public static class KPIPVReducer extends
			Reducer<Text, IntWritable, Text, IntWritable> {
		private IntWritable result = new IntWritable();

		public void reduce(Text key, Iterable<IntWritable> values,
				Context context) throws IOException, InterruptedException {
			int sum = 0;
			for (IntWritable val : values) {
				sum += val.get();
			}
			result.set(sum);
			context.write(key, result);
		}
	}

	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();
//	    conf.addResource("classpath:/hadoop/core-site.xml");
//	    conf.addResource("classpath:/hadoop/hdfs-site.xml");
//	    conf.addResource("classpath:/hadoop/mapred-site.xml");
//	    conf.addResource("classpath:/hadoop/yarn-site.xml");
//	    conf.set("mapred.jar", "myHadoop-0.0.1-SNAPSHOT.jar");

	 // configuration should contain reference to your namenode
	    FileSystem fs = FileSystem.get(conf);
	    // true stands for recursively deleting the folder you gave
	    fs.delete(new Path(args[1]), true);
	    
	    Job job = Job.getInstance(conf, "KPIPV");
//	    job.setJar("myHadoop-0.0.1-SNAPSHOT.jar");
		job.setJarByClass(org.myhadoop.mr.kpi.KPIPV.class);

	    job.setMapOutputKeyClass(Text.class);
	    job.setMapOutputValueClass(IntWritable.class);
	    job.setOutputKeyClass(Text.class);
	    job.setOutputValueClass(IntWritable.class);

		job.setMapperClass(KPIPVMapper.class);
		job.setCombinerClass(KPIPVReducer.class);
		job.setReducerClass(KPIPVReducer.class);

		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);
		// TODO: specify input and output DIRECTORIES (not files)
	    FileInputFormat.addInputPath(job, new Path(args[0]));
	    FileOutputFormat.setOutputPath(job, new Path(args[1]));
	    System.exit(job.waitForCompletion(true) ? 0 : 1);
	}

}
