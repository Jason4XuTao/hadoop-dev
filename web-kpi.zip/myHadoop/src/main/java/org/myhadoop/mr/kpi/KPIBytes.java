package org.myhadoop.mr.kpi;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class KPIBytes {
	public static class KPIBytesMapper extends
			Mapper<LongWritable, Text, Text, LongWritable> {
		private LongWritable bytes = new LongWritable();
		private Text word = new Text();

		public void map(LongWritable key, Text value, Context context)
				throws IOException, InterruptedException {
			KPI kpi = KPI.filterPVs(value.toString());
			if (kpi.isValid()) {
				word.set(kpi.getRequest());
				bytes.set(Long.valueOf(kpi.getBody_bytes_sent()));
				context.write(word, bytes);
			}
		}
	}

	public static class KPIBytesReducer extends
			Reducer<Text, LongWritable, Text, LongWritable> {
		private LongWritable result = new LongWritable();

		public void reduce(Text key, Iterable<LongWritable> values,
				Context context) throws IOException, InterruptedException {
			long sum = 0;
			for (LongWritable val : values) {
				sum += val.get();
			}
			result.set(sum);
			context.write(key, result);
		}
	}

	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();
//	    conf.addResource("classpath:/hadoop/core-site.xml");
//	    conf.addResource("classpath:/hadoop/hdfs-site.xml");
//	    conf.addResource("classpath:/hadoop/mapred-site.xml");
//	    conf.addResource("classpath:/hadoop/yarn-site.xml");
//	    conf.set("mapred.jar", "myHadoop-0.0.1-SNAPSHOT.jar");

	 // configuration should contain reference to your namenode
	    FileSystem fs = FileSystem.get(conf);
	    // true stands for recursively deleting the folder you gave
	    fs.delete(new Path(args[1]), true);
	    
	    Job job = Job.getInstance(conf, "KPIBytes");
//	    job.setJar("myHadoop-0.0.1-SNAPSHOT.jar");
		job.setJarByClass(org.myhadoop.mr.kpi.KPIBytes.class);

	    job.setMapOutputKeyClass(Text.class);
	    job.setMapOutputValueClass(LongWritable.class);
	    job.setOutputKeyClass(Text.class);
	    job.setOutputValueClass(LongWritable.class);

		job.setMapperClass(KPIBytesMapper.class);
		job.setCombinerClass(KPIBytesReducer.class);
		job.setReducerClass(KPIBytesReducer.class);

		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);
		// TODO: specify input and output DIRECTORIES (not files)
	    FileInputFormat.addInputPath(job, new Path(args[0]));
	    FileOutputFormat.setOutputPath(job, new Path(args[1]));
	    System.exit(job.waitForCompletion(true) ? 0 : 1);
	}

}
