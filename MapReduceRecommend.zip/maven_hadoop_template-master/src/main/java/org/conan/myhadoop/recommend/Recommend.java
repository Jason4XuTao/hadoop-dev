package org.conan.myhadoop.recommend;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.regex.Pattern;

import org.apache.hadoop.conf.Configuration;
import org.conan.myhadoop.hdfs.HdfsDAO;

public class Recommend {

//    public static final String HDFS = "hdfs://192.168.1.210:9000";
    public static final String HDFS = "/opt/eclipseProjects/maven_hadoop_template-master";
    public static final Pattern DELIMITER = Pattern.compile("[\t,]");

    public static void main(String[] args) throws Exception {
        Map<String, String> path = new HashMap<String, String>();
        path.put("data", "logfile/small2.csv");
        path.put("Step1Input", HDFS + "/recommend");
        path.put("Step1Output", path.get("Step1Input") + "/step1");
        path.put("Step2Input", path.get("Step1Output"));
        path.put("Step2Output", path.get("Step1Input") + "/step2");
        path.put("Step3Input1", path.get("Step1Output"));
        path.put("Step3Output1", path.get("Step1Input") + "/step3_1");
        path.put("Step3Input2", path.get("Step2Output"));
        path.put("Step3Output2", path.get("Step1Input") + "/step3_2");
        
        path.put("Step4Input1", path.get("Step3Output1"));
        path.put("Step4Input2", path.get("Step3Output2"));
        path.put("Step4Output", path.get("Step1Input") + "/step4");
        
        path.put("Step5Input1", path.get("Step3Output1"));
        path.put("Step5Input2", path.get("Step3Output2"));
        path.put("Step5Output", path.get("Step1Input") + "/step5");
        
        path.put("Step6Input", path.get("Step5Output"));
        path.put("Step6Output", path.get("Step1Input") + "/step6");
        

        Step1.run(path);
        Step2.run(path);
        Step3.run1(path);
        Step3.run2(path);
        Step4.run(path);
        
//        Step4_Update.run(path);
//        Step4_Update2.run(path);
        String userid = "6";
        System.out.println(userid + ":" + getRecommend(userid, path));
        
//        // hadoop fs -cat /user/hdfs/recommend/step4/part-00000
//        JobConf conf = config();
//        HdfsDAO hdfs = new HdfsDAO(HDFS, conf);
//        hdfs.cat("/user/hdfs/recommend/step4/part-00000");
        
        System.exit(0);
    }
    
    public static String getRecommend(String userID, Map<String, String> path) throws FileNotFoundException{
    	String result="";
        String srcfilename = path.get("data");
        Scanner srcReader = new Scanner(new File(srcfilename));
        Map<String, Float> srcMap = new HashMap<String, Float>();
        while(srcReader.hasNextLine()){
            String line = srcReader.nextLine();
            String[] split = line.split(",");
            if(split[0].equals(userID)){
            	srcMap.put(split[1], new Float(split[2]));
            }
        }
        srcReader.close();

        String recomdFilename = path.get("Step4Output") + "/part-r-00000";
        Map<String, Float> recomdMap = new HashMap<String, Float>();
        Scanner recomdReader = new Scanner(new File(recomdFilename));
        while(recomdReader.hasNextLine()){
            String line = recomdReader.nextLine();
            String[] split = line.split("\t");
            if(split[0].equals(userID)){
            	String[] isplit= split[1].split(",");
            	if(!srcMap.containsKey(isplit[0]))
            		recomdMap.put(isplit[0], new Float(isplit[1]));
            }
        }
        recomdReader.close();
        
        Map.Entry<String, Float> maxEntry = null;
        for (Map.Entry<String, Float> entry : recomdMap.entrySet())
        {
            if (maxEntry == null || entry.getValue().compareTo(maxEntry.getValue()) > 0)
            {
                maxEntry = entry;
            }
        }

        result = maxEntry.getKey();
    	return result;
   }

    public static Configuration config() {
    	Configuration conf = new Configuration();
//        JobConf conf = new JobConf(Recommend.class);
//        conf.setJobName("Recommand");
        conf.addResource("classpath:/hadoop/core-site.xml");
        conf.addResource("classpath:/hadoop/hdfs-site.xml");
//        conf.addResource("classpath:/hadoop/mapred-site.xml");
        conf.set("io.sort.mb", "1024");
        return conf;
    }

}
